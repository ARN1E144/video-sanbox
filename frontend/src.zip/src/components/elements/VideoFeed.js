// src/components/elements/VideoFeed.js
import React, { useEffect, useRef, useState } from "react";
import { runAction } from "../../utils/actionExecutor";
import { useActionContext } from "../../context/ActionContext";

export default function VideoFeed(props) {
  const {
    mode = "auto",       // "auto" | "local" | "remote"
    src,                 // remote URL (mp4/webm/m3u8)
    deviceId,
    enabled = true,
    playing = true,
    muted = true,
    mirror = true,
    poster,
    showSpinner = true,
    objectFit = "cover",
    borderRadius = 12,
    style = {},
    meta,                // optional meta for actions
    emitAction,          // remove from rest before spreading
    ...restProps
  } = props;

  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);
  const [error, setError] = useState(null);

  const videoRef = useRef(null);
  const streamRef = useRef(null);
  const hlsRef = useRef(null);

  const actionCtx = useActionContext?.();

  /* -------------------- Utils -------------------- */
  const isHlsUrl = (u) => typeof u === "string" && /\.m3u8(\?.*)?$/i.test(u.trim());

  const destroyHls = () => {
    if (hlsRef.current) {
      try { hlsRef.current.destroy(); } catch {}
      hlsRef.current = null;
    }
  };

  const stopLocalStream = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
    }
    if (videoRef.current) videoRef.current.srcObject = null;
  };

  const resetRemotePlayback = () => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    destroyHls();
    try { videoEl.pause(); } catch {}
    videoEl.srcObject = null;
    videoEl.removeAttribute("src");
    videoEl.load();
  };

  /* -------------------- Remote attach -------------------- */
  const attachRemote = async ({ videoEl, url }) => {
    if (!videoEl) return;

    stopLocalStream();
    resetRemotePlayback();

    videoEl.playsInline = true;
    videoEl.muted = muted;

    if (!url) {
      setError(null);
      return;
    }

    if (isHlsUrl(url)) {
      const canNativeHls = typeof videoEl.canPlayType === "function"
        && videoEl.canPlayType("application/vnd.apple.mpegurl") !== "";

      if (canNativeHls) {
        videoEl.src = url;
        videoEl.load();
        if (playing) videoEl.play().catch(() => {});
        setError(null);
        return;
      }

      try {
        const mod = await import("hls.js");
        const Hls = mod.default || mod;

        if (!Hls?.isSupported?.()) {
          setError("HLS not supported in this browser.");
          return;
        }

        const hls = new Hls();
        hlsRef.current = hls;

        hls.attachMedia(videoEl);

        hls.on(Hls.Events.MEDIA_ATTACHED, () => hls.loadSource(url));
        hls.on(Hls.Events.ERROR, (_evt, data) => {
          if (data?.fatal) setError(`HLS error: ${data?.type || "fatal"}`);
        });

        if (playing) setTimeout(() => videoEl.play().catch(() => {}), 0);
        setError(null);
        return;
      } catch {
        setError("This .m3u8 stream needs hls.js installed or use Safari native HLS.");
        return;
      }
    }

    // non-HLS
    videoEl.src = url;
    videoEl.load();
    if (playing) videoEl.play().catch(() => {});
    setError(null);
  };


  /* -------------------- Main effect -------------------- */
useEffect(() => {
  const videoEl = videoRef.current;
  if (!enabled) {
    destroyHls();
    stopLocalStream();
    if (videoEl) videoEl.pause();
    setError(null);
    return;
  }

  if (mode === "remote") {
    attachRemote({ videoEl, url: src || "" });
    return;
  }

  // LOCAL / AUTO
  resetRemotePlayback();
  if (videoEl) videoEl.playsInline = true;

  if (!playing) {
    if (videoEl) videoEl.pause();
    setError(null);
    return;
  }

  if (!navigator.mediaDevices?.getUserMedia) {
    setError("Camera not supported in this browser.");
    return;
  }

  let cancelled = false;

  const getCameraStream = async () => {
    try {
      // Try requested constraints first
      const constraints = {
        video: { width: { ideal: 1280 }, height: { ideal: 720 } },
      };
      if (deviceId) constraints.video.deviceId = { exact: deviceId };

      return await navigator.mediaDevices.getUserMedia(constraints);
    } catch (err) {
      if (err.name === "OverconstrainedError") {
        console.warn("Requested camera constraints failed, retrying with simpler constraints");
        return await navigator.mediaDevices.getUserMedia({ video: true });
      }
      throw err;
    }
  };

  (async () => {
    try {
      const stream = await getCameraStream();
      if (cancelled) {
        stream.getTracks().forEach((t) => t.stop());
        return;
      }

      streamRef.current = stream;
      if (videoEl) {
        videoEl.srcObject = stream;
        videoEl.muted = muted;
        videoEl.play().catch(() => {});
      }
      setError(null);
    } catch (err) {
      console.error("getUserMedia failed:", err);
      setError(err?.message || "Camera error");
    }
  })();

  return () => { cancelled = true; };
}, [mode, src, deviceId, enabled, playing, muted]);


  /* -------------------- Playing effect -------------------- */
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (playing) {
      video.play().catch(() => {});
    } else {
      video.pause();
    }
  }, [playing]);

  /* -------------------- Muted effect -------------------- */
  useEffect(() => {
    const videoEl = videoRef.current;
    if (!videoEl) return;

    videoEl.muted = muted;
    if (streamRef.current?.getAudioTracks) {
      streamRef.current.getAudioTracks().forEach((track) => {
        track.enabled = !muted;
      });
    }
  }, [muted]);

  /* -------------------- Runtime Actions -------------------- */
  const handleAction = (action) => {
    if (!actionCtx?.emit) return;
    const name = action?.name || action?.value;
    if (name) runAction(name, props.id, actionCtx.emit);
  };

  const availableActions = meta?.actions || [];

  return (
    <div
      style={{
        width: "100%",
        height: "100%",
        position: "relative",
        overflow: "hidden",
        borderRadius,
        backgroundColor: "#000",
        ...style,
      }}
      {...restProps} // safe, emitAction removed
    >
      {/* Poster */}
      {isLoading && poster && (
        <img
          src={poster}
          alt="Video poster"
          className="absolute inset-0 w-full h-full object-cover"
          draggable={false}
        />
      )}

      {/* Spinner */}
      {isLoading && showSpinner && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/30">
          <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent" />
        </div>
      )}

      <video
        ref={videoRef}
        playsInline
        muted={muted}
        onLoadedData={() => setIsLoading(false)}
        onCanPlay={() => setIsLoading(false)}
        onError={() => { setHasError(true); setIsLoading(false); }}
        style={{
          width: "100%",
          height: "100%",
          objectFit,
          transform: mirror ? "scaleX(-1)" : "none",
        }}
      />

      {!enabled && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(0,0,0,0.6)",
            color: "#fff",
            fontSize: 12,
          }}
        >
          Camera off
        </div>
      )}

      {error && (
        <div
          style={{
            position: "absolute",
            inset: 0,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            background: "rgba(0,0,0,0.7)",
            color: "tomato",
            fontSize: 12,
            padding: 8,
            textAlign: "center",
          }}
        >
          {error}
        </div>
      )}

      {/* Optional runtime actions UI */}
      {availableActions.length > 0 && (
        <div style={{ position: "absolute", bottom: 4, left: 4, display: "flex", gap: 4 }}>
          {availableActions.map((act, i) => (
            <button
              key={i}
              onClick={() => handleAction(act)}
              style={{
                fontSize: 10,
                padding: "2px 4px",
                borderRadius: 4,
                backgroundColor: "#fff2",
              }}
            >
              {act.label || act.value}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
