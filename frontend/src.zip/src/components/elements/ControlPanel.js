// src/components/elements/ControlPanel.js

import React, { useMemo } from "react";
import * as Icons from "lucide-react";

import { useActionContext } from "../../context/ActionContext";
import { useAuth } from "../../context/AuthContext";
import { useProjectContext } from "../../context/ProjectContext";

import { runAction } from "../../utils/actionExecutor";

export default function ControlPanel({
  id,
  layout = "vertical",
  controls = [],
}) {
  /* =========================================================
     CONTEXTS
  ========================================================= */

  const projectCtx = useProjectContext() || {};
  const actionCtx = useActionContext() || {};
  const authCtx = useAuth() || {};

  const {
    elements = [],
    updateElement,
  } = projectCtx;

  const {
    notify,
    bindings = {},
    updateBinding,
    getBinding,
    clearBinding,
    appendFeed,


    // 🔥 AGORA METHODS
    agora,
    leaveCall,
    joinCall,
    toggleMic,
    toggleAudio,
    toggleVideo,
    startScreenShare,
    stopScreenShare,
    startStream,
    stopStream,
  } = actionCtx;

  const {
    role = "participant",
  } = authCtx;

  /* =========================================================
     SAFE STATE
  ========================================================= */

  const binding = bindings?.[id] || {};

  const safeControls = useMemo(() => {
    return Array.isArray(controls) ? controls : [];
  }, [controls]);

  const safeElements = useMemo(() => {
    return Array.isArray(elements) ? elements : [];
  }, [elements]);

  /* =========================================================
     VISIBILITY
  ========================================================= */

  const isVisible = (ctrl) => {
    if (!ctrl) return false;

    const rules = ctrl.visibleWhen;

    if (!rules) return true;

    // ROLE
    if (
      Array.isArray(rules.role) &&
      !rules.role.includes(role)
    ) {
      return false;
    }

    // CALL STATE
    if (
      Array.isArray(rules.callState) &&
      !rules.callState.includes(binding?.callState)
    ) {
      return false;
    }

    return true;
  };

  /* =========================================================
     ACTIVE STATE
  ========================================================= */

  const isActive = (ctrl) => {
    if (!ctrl) return false;

    const rules = ctrl.activeWhen;

    if (!rules) return false;

    if (rules.binding) {
      return Object.entries(rules.binding).every(
        ([key, val]) => binding?.[key] === val
      );
    }

    return false;
  };

  /* =========================================================
     FILTERED CONTROLS
  ========================================================= */

  const visibleControls = useMemo(() => {
    return safeControls.filter(isVisible);
  }, [safeControls, role, binding]);

  /* =========================================================
     LAYOUT
  ========================================================= */

  const containerStyle = {
    display: "flex",
    flexDirection: layout === "vertical" ? "column" : "row",
    gap: 8,
    width: "100%",
  };

  /* =========================================================
     ACTION EXECUTION
  ========================================================= */

  const handleControlClick = async (ctrl) => {
    try {
      if (!ctrl?.action) {
        console.warn("⚠️ No action assigned", ctrl);
        return;
      }

      console.log(
        "%c[CONTROL CLICK]",
        "color: blue; font-weight: bold;",
        ctrl
      );

      // 🔥 SAFE LOOKUPS
      const targetElement = ctrl?.targetId
        ? safeElements.find((el) => el?.id === ctrl.targetId)
        : null;

      const sourceElement = ctrl?.sourceId
        ? safeElements.find((el) => el?.id === ctrl.sourceId)
        : null;

      /* =====================================================
         FULL ACTION CONTEXT
      ===================================================== */

      const ctx = {
        /* CORE */
        role,
        notify,
        bindings,
        updateBinding,
        getBinding,
        clearBinding,
        appendFeed,

        /* ELEMENTS */
        elements: safeElements,
        updateElement,

        /* CONTROL */
        control: ctrl,
        config: ctrl?.config || {},

        /* TARGETING */
        source: sourceElement || null,
        target: targetElement || null,
        sourceId: ctrl?.sourceId || null,
        targetId: ctrl?.targetId || null,

        /* AGORA DIRECT METHODS */
        agora: {
          agora,

          leaveCall,
          joinCall,

          toggleMic,
          toggleAudio,
          toggleVideo,

          startScreenShare,
          stopScreenShare,

          startStream,
          stopStream,
        },

        /* RAW METHODS (fallback support) */
        leaveCall,
        joinCall,

        toggleMic,
        toggleAudio,
        toggleVideo,

        startScreenShare,
        stopScreenShare,

        startStream,
        stopStream,
      };

      console.log(
        "%c[CONTROL EXECUTION]",
        "color: blue; font-weight: bold;",
        {
          action: ctrl.action,
          ctx,
        }
      );

      console.log(
        "%c[CONTROL DATA]",
        "color: red; font-weight: bold;",
        ctrl
      );

      await runAction(
        ctrl.action,
        ctx,
        {
          ...(ctrl.config || {}),

          bindId:
            ctrl.bindId ??
            ctrl.targetId ??
            ctx.targetId ??
            ctrl.id ??
            null,
        }
      );
    } catch (err) {
      console.error(
        "❌ Control execution failed:",
        err
      );

      notify?.("Control action failed");
    }
  };

  /* =========================================================
     RENDER
  ========================================================= */

  return (
    <div style={containerStyle}>
      {visibleControls.map((ctrl) => {
        const Icon =
          Icons?.[ctrl?.icon] || Icons.Circle;

        const active = isActive(ctrl);

        return (
          <button
            key={ctrl.id}
            title={ctrl.label || "Control"}
            onClick={() => handleControlClick(ctrl)}
            style={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",

              width: 42,
              height: 42,

              padding: 10,

              borderRadius: 10,

              background: active
                ? "#2563eb"
                : "#ffffff",

              color: active
                ? "#ffffff"
                : "#000000",

              border: active
                ? "1px solid #2563eb"
                : "1px solid #d4d4d8",

              cursor: "pointer",

              transition: "all 0.15s ease",

              boxShadow:
                "0 1px 2px rgba(0,0,0,0.08)",
            }}
          >
            <Icon size={16} />
          </button>
        );
      })}
    </div>
  );
}