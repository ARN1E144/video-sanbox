// src/actions/actionsRegistry.js

import startCall from "./call/startCall";
import acceptCall from "./call/acceptCall";
import endCall from "./call/endCall";
import fetchAvailableCalls from "./call/fetchAvailableCalls";
import leaveCall from "./call/leaveCall";
import spotlightUser from "./call/spotlightUser";

import startStream from "./video/startStream";
import stopStream from "./video/stopStream";
import loadVideo from "./video/loadVideo";
import loadRemote from "./video/loadRemote";
import togglePlay from "./video/togglePlay";

import sendMessage from "./chat/sendMessage";

import AgoraStartStream from "./agora/StartStream";
import AgoraStopStream from "./agora/StopStream";
import AgoraTogglePlay from "./agora/TogglePlay";

import toggleMic from "./system/toggleMic";
import api from "../../src/services/api";

/* =========================================================
   🔥 ACTION CONSTANTS (UI / reference layer only)
========================================================= */

export const ACTIONS = {
  /* AGORA */
  AGORA_START_STREAM: "agora.startStream",
  AGORA_STOP_STREAM: "agora.stopStream",
  AGORA_TOGGLE_PLAY: "agora.togglePlay",
  AGORA_TOGGLE_VIDEO: "agora.toggleVideo",
  AGORA_TOGGLE_AUDIO: "agora.toggleAudio",
  AGORA_LEAVE_CALL: "agora.leaveCall",

  /* CALL */
  CALL_START: "call.startCall",
  CALL_ACCEPT: "call.acceptCall",
  CALL_END: "call.endCall",
  CALL_FETCH: "call.fetchAvailableCalls",
  CALL_LEAVE: "call.leaveCall",
  CALL_SPOTLIGHT: "call.spotlightUser",

  /* VIDEO */
  VIDEO_START_STREAM: "video.startStream",
  VIDEO_STOP_STREAM: "video.stopStream",
  VIDEO_LOAD_VIDEO: "video.loadVideo",
  VIDEO_LOAD_REMOTE: "video.loadRemote",
  VIDEO_TOGGLE_PLAY: "video.togglePlay",

  /* CHAT */
  CHAT_SEND_MESSAGE: "chat.sendMessage",

  /* SYSTEM */
  SYSTEM_TOGGLE_MIC: "system.toggleMic",
  SYSTEM_API: "system.api",
};

/* =========================================================
   🔥 HELPERS
========================================================= */

const missingAgora = (ctx, method, label) => {
  console.warn(`⚠️ Agora ${method} not available in ctx`);
  ctx?.notify?.(`${label} unavailable`);
  return null;
};

/* =========================================================
   🔥 ACTION FACTORY
========================================================= */

const createAction = ({
  value,
  label,
  category,
  run,
  roles = null,
  runtime = true,
  targets = [],
  source = ["ui", "inspector", "runtime"],
  params,
}) => ({
  value,
  label,
  category,
  run,
  runtime,              // NEW (replaces roles)
  targets,
  source,

  // 🔥 ALWAYS GUARANTEE OBJECT
  params: params || {},
});

/* =========================================================
   🔥 NESTED ACTION REGISTRY (OPTION B)
========================================================= */

export const actionRegistry = {
  /* =========================================================
     🎥 AGORA
  ========================================================= */
  agora: {
    startStream: createAction({
      value: ACTIONS.AGORA_START_STREAM,
      label: "Start Stream",
      category: "agora",

      run: async (ctx, params) => {
        if (AgoraStartStream) return await AgoraStartStream(ctx, params);
        return missingAgora(ctx, "startStream", "Start stream");
      },

      targets: ["VideoFeed", "AgoraFeed"],
    }),

    stopStream: createAction({
      value: ACTIONS.AGORA_STOP_STREAM,
      label: "Stop Stream",
      category: "agora",

      run: async (ctx, params) => {
        if (AgoraStopStream) return await AgoraStopStream(ctx, params);
        return missingAgora(ctx, "stopStream", "Stop stream");
      },

      targets: ["VideoFeed", "AgoraFeed"],
    }),

    togglePlay: createAction({
      value: ACTIONS.AGORA_TOGGLE_PLAY,
      label: "Toggle Play",
      category: "agora",

      run: async (ctx, params) => {
        if (AgoraTogglePlay) return await AgoraTogglePlay(ctx, params);
        return missingAgora(ctx, "togglePlay", "Playback");
      },

      targets: ["VideoFeed", "AgoraFeed"],
    }),

    toggleVideo: createAction({
      value: ACTIONS.AGORA_TOGGLE_VIDEO,
      label: "Toggle Video",
      category: "agora",

      run: async (ctx) => {
        if (!ctx?.agora?.toggleVideo) {
          return missingAgora(ctx, "toggleVideo", "Video controls");
        }
        return await ctx.agora.toggleVideo();
      },

      targets: ["VideoFeed", "AgoraFeed"],
    }),

    toggleAudio: createAction({
      value: ACTIONS.AGORA_TOGGLE_AUDIO,
      label: "Toggle Audio",
      category: "agora",

      run: async (ctx) => {
        if (!ctx?.agora?.toggleAudio) {
          return missingAgora(ctx, "toggleAudio", "Audio controls");
        }
        return await ctx.agora.toggleAudio();
      },

      targets: ["VideoFeed", "AgoraFeed"],
    }),

    leaveCall: createAction({
      value: ACTIONS.AGORA_LEAVE_CALL,
      label: "Leave Call",
      category: "agora",

      run: async (ctx) => {
        if (!ctx?.agora?.leaveCall) {
          return missingAgora(ctx, "leaveCall", "Leave call");
        }
        return await ctx.agora.leaveCall();
      },

      targets: ["CallPanel", "AgoraFeed", "VideoFeed"],
    }),
  },

  /* =========================================================
     📞 CALL
  ========================================================= */
  call: {
    startCall: createAction({
      value: ACTIONS.CALL_START,
      label: "Start Call",
      category: "call",
      run: startCall,
      targets: ["CallPanel"],
    }),

    acceptCall: createAction({
      value: ACTIONS.CALL_ACCEPT,
      label: "Accept Call",
      category: "call",
      run: acceptCall,
      roles: ["participant"],
      targets: ["CallPanel"],
    }),

    endCall: createAction({
      value: ACTIONS.CALL_END,
      label: "End Call",
      category: "call",
      run: endCall,
      targets: ["CallPanel"],
    }),

    fetchAvailableCalls: createAction({
      value: ACTIONS.CALL_FETCH,
      label: "Fetch Calls",
      category: "call",
      run: fetchAvailableCalls,
      roles: ["participant"],
      targets: ["CallPanel"],
    }),

    leaveCall: createAction({
      value: ACTIONS.CALL_LEAVE,
      label: "Leave Call",
      category: "call",
      run: leaveCall,
      targets: ["CallPanel"],
    }),

    spotlightUser: createAction({
      value: ACTIONS.CALL_SPOTLIGHT,
      label: "Spotlight User",
      category: "call",
      run: spotlightUser,
      runtime: true,
      targets: ["VideoFeed", "AgoraFeed"],
    }),
  },

  /* =========================================================
     🎥 VIDEO
  ========================================================= */
  video: {
    startStream: createAction({
      value: ACTIONS.VIDEO_START_STREAM,
      label: "Start Stream",
      category: "video",
      run: startStream,
      targets: ["VideoFeed"],
    }),

    stopStream: createAction({
      value: ACTIONS.VIDEO_STOP_STREAM,
      label: "Stop Stream",
      category: "video",
      run: stopStream,
      targets: ["VideoFeed"],
    }),

    loadVideo: createAction({
      value: ACTIONS.VIDEO_LOAD_VIDEO,
      label: "Load Video",
      category: "video",
      run: loadVideo,
      targets: ["VideoFeed"],
      params: {
        src: { type: "string", default: "" },
      },
    }),

    loadRemote: createAction({
      value: ACTIONS.VIDEO_LOAD_REMOTE,
      label: "Load Remote Stream",
      category: "video",
      run: loadRemote,
      targets: ["VideoFeed"],
    }),

    togglePlay: createAction({
      value: ACTIONS.VIDEO_TOGGLE_PLAY,
      label: "Toggle Play",
      category: "video",
      run: togglePlay,
      targets: ["VideoFeed"],
    }),
  },

  /* =========================================================
     💬 CHAT
  ========================================================= */
  chat: {
    sendMessage: createAction({
      value: ACTIONS.CHAT_SEND_MESSAGE,
      label: "Send Message",
      category: "chat",
      run: sendMessage,
      targets: ["ChatPanel"],
      params: {
        message: { type: "string", default: "" },
      },
    }),
  },

  /* =========================================================
     ⚙️ SYSTEM
  ========================================================= */
  system: {
    toggleMic: createAction({
      value: ACTIONS.SYSTEM_TOGGLE_MIC,
      label: "Toggle Mic",
      category: "system",
      run: toggleMic,
      targets: ["VideoFeed", "AgoraFeed"],
    }),

    api: createAction({
      value: ACTIONS.SYSTEM_API,
      label: "API Call",
      category: "system",
      run: api,
      targets: ["Text", "Container"],
      params: {
        endpoint: { type: "string", default: "" },
        method: {
          type: "select",
          options: [
            { label: "GET", value: "GET" },
            { label: "POST", value: "POST" },
          ],
        },
      },
    }),
  },
};

/* =========================================================
   🔥 OPTIONAL HELPERS (UPDATED LATER IN STEP 2)
========================================================= */

export const getAction = (value) => {
  const [category, name] = value.split(".");
  return actionRegistry?.[category]?.[name] || null;
};

export const getAllActions = () =>
  Object.values(actionRegistry).flatMap((cat) =>
    Object.values(cat)
  );