import React, { useContext } from 'react';
import PromptForm from './components/PromptForm';
import TemplatePreview from './components/TemplatePreview';
import ProjectSidebar from './components/ProjectSidebar';
import { ProjectContext } from './context/ProjectContext';
import TemplateCarousel from './components/TemplateCarousel';


export default function MainApp() {
  const { projectSchema } = useContext(ProjectContext);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', height: '100vh' }}>
      <ProjectSidebar />
      <div style={{ padding: 16, display: 'grid', gridTemplateRows: 'auto 1fr auto', gap: 12 }}>
        <PromptForm />
        <TemplatePreview schema={projectSchema} />
        <TemplateCarousel />  {/* 👈 Add this line */}
      </div>
    </div>
  );
}