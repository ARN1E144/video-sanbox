// src/ui/index.js

// Import all visual components used in templates
import App from '../components/App';
import AppBar from '../components/AppBar';
import Container from '../components/Container';
import VideoFeed from '../components/VideoFeed';
import ChatPanel from '../components/ChatPanel';
import MicButton from '../components/MicButton';
import TextBox from '../components/TextBox';
import ControlButton from '../components/ControlButton';

// Export them so TemplateMiniPreview and TemplatePreview can use them dynamically
export {
  App,
  AppBar,
  Container,
  VideoFeed,
  ChatPanel,
  MicButton,
  TextBox,
  ControlButton,
};
